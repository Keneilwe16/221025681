import 'dart:io';

class Profile {
  String name;
  String surname;
  String phone;
  String email;
  String role;
  String language;
  File? image;

  Profile({
    required this.name,
    required this.surname,
    required this.phone,
    required this.email,
    required this.role,
    required this.language,
    this.image,
  });
}
