import '../model/profile_model.dart';

class ProfileViewModel {
  Profile profile = Profile(
    name: "Keneilwe",
    surname: "Mokone",
    phone: "063 203 6263",
    email: "evelynK696@gmail.com",
    role: "Flutter Developer",
    language: "Dart",
  );

  void updateProfile(Profile updatedProfile) {
    profile = updatedProfile;
  }
}
